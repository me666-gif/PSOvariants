function dist = hamming_distance(vec1, vec2)
    dist = sum(vec1 ~= vec2);
end