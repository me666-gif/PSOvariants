clear,clc,close all
rng(2)
%% 使用CEC2020
Func_name = 'F6'; %测试函数名
dim = 10; 
[lb,ub,dim,fobj] = Get_CEC2020_details(Func_name,dim); %获取函数变量上下界，维度，目标函数句柄

pop = 50; %种群数量
maxIter = 2000; %最大迭代次数
%求解
[Best_pos1,Best_fitness1, Iter_curve1] = PSO(pop, maxIter, lb, ub, dim,fobj);
[Best_pos2,Best_fitness2, Iter_curve2] = DM_QPSO(pop, maxIter, lb, ub, dim,fobj);

%绘图
figure
subplot(1,2,1)
[x,y,f] = Plot_CEC2020(Func_name,dim);
surfc(x,y,f,'LineStyle','none');
colormap winter
title(Func_name);
subplot(1,2,2)
grid on;
semilogy(Iter_curve1, '--','linewidth', 1.5); hold on
semilogy(Iter_curve2, '--','linewidth', 1.5)
legend('PSO','MSAPO')
xlabel('迭代次数');
ylabel('适应度值');
