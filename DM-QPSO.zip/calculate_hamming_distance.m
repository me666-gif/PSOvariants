function mean_H = calculate_hamming_distance(X, threshold)

    M = size(X, 1);
    H = zeros(M, M);  
    
    for i = 1:M-1
        for j = i+1:M
            diff = abs(X(i, :) - X(j, :)) > threshold; 
            H(i, j) = sum(diff);  
            H(j, i) = H(i, j);    
        end
    end
   
    mean_H = mean(H, 2);  
end